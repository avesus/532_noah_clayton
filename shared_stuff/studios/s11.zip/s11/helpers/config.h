#ifndef _CONFIG_H_
#define _CONFIG_H_


//#define debug_mode 
//#define low_verbose
//#define med_verbose
//#define high_verbose
#define USAGE_CHECK
typedef unsigned long nanoseconds;

#endif
