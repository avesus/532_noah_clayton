#ifndef _INT_CLASS_H_
#define _INT_CLASS_H_
class int_class {
 public:
  virtual void operator() (char&)=0;
};

#endif
