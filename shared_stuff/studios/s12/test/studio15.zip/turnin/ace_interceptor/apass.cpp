#include "apass.h"

//void pass_through::operator() (char&) {
  
 
//}
